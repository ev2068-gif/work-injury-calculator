# 職災工資補償試算器（2026）

免安裝、行動裝置與電腦均可透過瀏覽器使用的職災工資補償試算工具。

## 用 GitHub Pages 發布

1. 登入 GitHub，建立名稱為 `work-injury-calculator` 的 **Public** repository。
2. 將這個 ZIP **解壓縮**，在 repository 的 `main` 分支根目錄上傳 `index.html`（也可上傳 `README.md`）。
3. 進入 repository → **Settings** → **Pages**。
4. Source 選 **Deploy from a branch**，Branch 選 **main**，Folder 選 **/(root)**，按 **Save**。
5. 發布後在 Settings → Pages 取得網址：`https://你的帳號.github.io/work-injury-calculator/`。

### 注意

- GitHub 預設不會自動解壓你上傳的 ZIP，必須先解壓縮並上傳 `index.html`。
- GitHub Pages 預設是公開網頁，不具個別客戶密碼保護。
- 這是工資補償試算，並非勞保局核定；法律責任、抵充條件應另行查核。
- 程式運算在使用者瀏覽器本機進行，請勿在公開儲存庫上傳任何個人資料。
